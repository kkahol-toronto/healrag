import { Info24Regular } from "@fluentui/react-icons";
import { Button } from "@fluentui/react-components";
import { Callout, IStackTokens, Stack, IStackStyles, initializeIcons } from "@fluentui/react";
import { useBoolean, useId } from "@fluentui/react-hooks";
import { useTranslation } from "react-i18next";

const stackTokens: IStackTokens = {
    childrenGap: 4,
    maxWidth: 300
};

const labelCalloutStackStyles: Partial<IStackStyles> = { root: { padding: 20 } };

interface IHelpCalloutProps {
    label: string | undefined;
    labelId: string;
    fieldId: string | undefined;
    helpText: string;
}

export const HelpCallout = (props: IHelpCalloutProps): JSX.Element => {
    const [isCalloutVisible, { toggle: toggleIsCalloutVisible }] = useBoolean(false);
    const descriptionId: string = useId("description");
    const iconButtonId: string = useId("iconButton");
    const { t } = useTranslation();

    return (
        <>
            <Stack horizontal verticalAlign="center" tokens={stackTokens}>
                <label id={props.labelId} htmlFor={props.fieldId}>
                    {props.label}
                </label>
                <Button
                    icon={<Info24Regular />}
                    title={t("tooltips.info")}
                    aria-label={t("tooltips.info")}
                    onClick={toggleIsCalloutVisible}
                    style={{ marginBottom: -3 }}
                />
            </Stack>
            {isCalloutVisible && (
                <Callout target={"#" + iconButtonId} setInitialFocus onDismiss={toggleIsCalloutVisible} ariaDescribedBy={descriptionId} role="alertdialog">
                    <Stack tokens={stackTokens} horizontalAlign="start" styles={labelCalloutStackStyles}>
                        <span id={descriptionId}>{props.helpText}</span>
                        <Button icon={<Info24Regular />} onClick={toggleIsCalloutVisible}>{t("labels.closeButton")}</Button>
                    </Stack>
                </Callout>
            )}
        </>
    );
};
