import os
# from dotenv import load_dotenv
# load_dotenv()
from azure.storage.blob import BlobServiceClient

CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")  # or hardcode for testing
CONTAINER_NAME = os.getenv("AZURE_CONTAINER_NAME")  # or hardcode for testing

print("Connection String:", CONNECTION_STRING)
print("Container Name:", CONTAINER_NAME)

try:
    blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
    container_client = blob_service_client.get_container_client(CONTAINER_NAME)
    props = container_client.get_container_properties()
    print("✅ Connected! Container properties:", props)
except Exception as e:
    print("❌ Failed to connect:", e)